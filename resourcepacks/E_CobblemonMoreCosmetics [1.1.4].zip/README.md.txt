MoreCosmetics 

Made by Archaeusdev

This is a Cobblemon Cosmetics addon!

Put the zip into your datapacks and resourcepacks folder to activate it!

--------------------

List of Pokémon Cosmetics:

Covert Style Lucario - Give Lucario a Covert Cloak OR use command /pokegive lucario aspect=covert

Steampunk Style Articuno - Give Articuno a Copper Ingot OR use command /pokegive articuno aspect=steampunk

Steampunk Style Zapdos - Give Zapdos a Copper Ingot OR use command /pokegive zapdos aspect=steampunk

Steampunk Style Moltres - Give Moltres a Copper Ingot OR use command /pokegive moltres aspect=steampunk

Eternal Style Tinkaton - Give Tinkaton a Wither Rose OR use command /pokegive tinkaton aspect=eternal

Cheerleader Style Plusle - Give Plusle a Pink Wool OR use command /pokegive plusle aspect=cheerleader

Cheerleader Style Minun - Give Minun a Lime Wool OR use command /pokegive minun aspect=cheerleader

New Year Style Drampa - Give Drampa a Lantern OR use command /pokegive drampa aspect=newyear

Ancient Style Cyclizar - Give Cyclizar a Red Wool OR use command /pokegive cyclizar aspect=ancient

Royal Style Carbink - Give Carbink a King's Rock OR use command /pokegive carbink aspect=royal

Chef Style Typhlosion - Give Typhlosion a White Wool OR use command /pokegive typhlosion aspect=chef

Dignified Style Wooper - Give Wooper an Emerald OR use command /pokegive wooper aspect=dignified (PALDEAN FORM COMPAT)

Ninja Style Decidueye - Give Decidueye a Covert Cloak OR use command /pokegive decidueye aspect=ninja

Mega Greninja Style Ceruledge - Give Ceruledge a Mystic Water OR use command /pokegive ceruledge aspect=mgreninja

Fighter Style Latios - Give Latios an Iron Ingot OR use command /pokegive latios aspect=fighter

Legend Style Grumpig - Give Grumpig a Potato OR use command /pokegive grumpig aspect=legend RIP Technoblade

Chef Style Snorlax - Give Snorlax a White Wool OR use command /pokegive snorlax aspect=chef

Warmonger Style Incineroar - Give Incineroar an Iron Ingot OR use command /pokegive incineroar aspect=warmonger

Uva Style Smoliv - Give Smoliv a Sweet Berries OR use command /pokegive smoliv aspect=uva

Knight Style Charizard - Give Charizard an Iron Ingot OR use command /pokegive charizard aspect=knight

Yellow Hat Style Pichu Line - Give any member of the Pichu line a Yellow Wool OR use command /pokegive pichu/pikachu/raichu aspect=yellowhat

WINTER BUNDLE 2025

Holiday Style Vulpix - Give Vulpix a Snow Block OR use command /pokegive vulpix aspect=holiday (ALOLAN FORM COMPAT)

Aurora Style Umbreon - Give Umbreon a Snow Block OR use command /pokegive umbreon aspect=aurora

Skier Style Weavile - Give Weavile a Snow Block OR use command /pokegive weavile aspect=skier

Ice Dragon Style Gardevoir - Give Gardevoir a Snow Block OR use command /pokegive aspect=icedragon

Warm Style Furfrou - Give Furfrou a Snow Block OR use command /pokegive furfrou aspect=warm

Boundary Style Mewtwo - Give Mewtwo a Snow Block OR use command /pokegive mewtwo aspect=boundary

Winter Style Greninja - Give Greninja a Snow Block OR use command /pokegive greninja aspect=winter

UNITED FESTIVAL

Festival Style Throh - Give Throh a Black Belt OR use command /pokegive throh aspect=festival

Festival Style Sawk - Give Sawk a Black Belt OR use command /pokegive sawk aspect=festival

Captain Style Cinderace - Give Cinderace a Black Wool OR use command /pokegive cinderace aspect=captain

Steampunk Style Ho-oh - Give Ho-oh a Gold Ingot OR use command /pokegive hooh aspect=steampunk

Ghost Style Zoroark - Give Zoroark a Spell Tag OR use command /pokegive zoroark aspect=ghost

VALENTINES BUNDLE 2026

Valentines Style Eevee - Give Eevee a Love Sweet OR use command /pokegive eevee aspect=valentines

Valentines Style Vaporeon - Give Vaporeon a Love Sweet OR use command /pokegive vaporeon aspect=valentines

Valentines Style Jolteon - Give Jolteon a Love Sweet OR use command /pokegive jolteon aspect=valentines

Valentines Style Flareon - Give Flareon a Love Sweet OR use command /pokegive flareon aspect=valentines

Valentines Style Roserade - Give Roserade a Love Sweet OR use command /pokegive roserade aspect=valentines

--------------------

List of Trainer Cosmetics (INSTALL RECIPEPACK FOR SURVIVAL RECIPES)

Alola Cap - Use command /give @s minecraft:carved_pumpkin[minecraft:custom_model_data=1] 

Lucario Hood - Use command /give @s minecraft:carved_pumpkin[minecraft:custom_model_data=2(3 for shiny)]

Mystical Mask - Use command /give @s minecraft:carved_pumpkin[minecraft:custom_model_data=4]

Baneful Fox Mask - Use command /give @s minecraft:carved_pumpkin[minecraft:custom_model_data=5(6 for shiny)]

Umbreon Mask - Use command /give @s minecraft:carved_pumpkin[minecraft:custom_model_data=7(8 for shiny)] 

Mimikyu Mask - Use command /give @s minecraft:carved_pumpkin[minecraft:custom_model_data=9(10 for shiny)] 

Yellow Hat - Use command /give @s  minecraft:carved_pumpkin[minecraft:custom_model_data=11] 

--------------------

Special thanks to: 

Davrial
Orion0333